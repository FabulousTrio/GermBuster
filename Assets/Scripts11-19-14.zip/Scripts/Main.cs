﻿using UnityEngine;
using System.Collections;

public class Main : MonoBehaviour {
	
	
	public int health;
	float speed;
	SpriteRenderer sprites;
	
	void movement()
	{
		
	}
	
	void attack()
	{
		
	}
	
	// Use this for initialization
	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		
	}
	
	
}
